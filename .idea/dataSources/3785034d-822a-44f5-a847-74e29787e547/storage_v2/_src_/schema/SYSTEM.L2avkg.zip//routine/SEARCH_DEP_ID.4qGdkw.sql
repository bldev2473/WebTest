create function search_dep_id(
  v_name in fc_employees.last_name%type
)
  return number
  is
  v_dept_no fc_employees.department_id%type;
  begin
    begin 
    select DEPARTMENT_ID into v_dept_no from fc_employees where upper(LAST_NAME) = upper(v_name);
      exception
    when no_data_found then dbms_output.put_line('데이터가 없습니다');
    when too_many_rows then dbms_output.put_line('자료가 2건 이상입니다');
    when others then dbms_output.put_line('기타 에러입니다');
  end;
  return v_dept_no;
  end;
/

