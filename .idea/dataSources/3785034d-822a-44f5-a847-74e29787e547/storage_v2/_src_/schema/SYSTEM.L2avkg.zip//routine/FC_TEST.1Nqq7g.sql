create function fc_test (
  v_last_name in fc_employees.last_name%type,
  v_dept_name out fc_departments.department_name%type,
  v_sal out fc_employees.salary%type
)
  return number
  is
  v_dept_no fc_employees.department_id%type;
  begin
    select DEPARTMENT_ID into v_dept_no from fc_employees where LAST_NAME = v_last_name;
    select DEPARTMENT_NAME into v_dept_name from fc_departments where DEPARTMENT_ID = v_dept_no;
    select SALARY into v_sal from fc_employees where LAST_NAME = v_last_name;
    dbms_output.put_line('LAST_NAME : ' || v_last_name);
    dbms_output.put_line('DEPARTMENT_NAME : ' || v_dept_name);
    dbms_output.put_line('SALARY : ' || v_sal);
    return v_dept_no;
  end;
/

