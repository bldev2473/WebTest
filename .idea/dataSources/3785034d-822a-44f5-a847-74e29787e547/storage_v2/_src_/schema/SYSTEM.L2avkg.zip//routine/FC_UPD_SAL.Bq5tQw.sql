create function fc_upd_sal(
  v_emp_no in number
)
  return number -- 반환 자료형
  is
  v_sal fc_employees.salary%type; -- %type : salary가 가지고 있는 자료형 사용
  begin
    select salary into v_sal from fc_employees --employees 테이블에서 salary를 v_sal 변수에 저장
    where EMPLOYEE_ID = v_emp_no;
    return v_sal;
  end;
/

