create trigger EMP_TEST_DEL
  after delete
  on EMP_TRI
  for each row
  begin
    delete from emp_empty where EMPLOYEE_ID = :old.EMPLOYEE_ID;
  end;
/

