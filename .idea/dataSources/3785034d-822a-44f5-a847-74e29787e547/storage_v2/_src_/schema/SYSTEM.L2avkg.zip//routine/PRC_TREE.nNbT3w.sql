create procedure prc_tree(
  v_emp_code in varchar2,
  p_code out varchar2,
  t_code out varchar2
)
  is
  begin
    -- EMPLOYEES 테이블에서 인자 v_emp_code 값에 해당하는 EMPLOYEE_ID를 갖는 행의 DEPARTMENT_ID를 p_code 변수에 대입
    select DEPARTMENT_ID into p_code
    from proc_employees
    where EMPLOYEE_ID = v_emp_code;
    t_code := '2';

    if p_code <> '20' then
      -- DEPARTMENTS 테이블에서 p_code 값에 해당하는 DEPARTMENT_ID 갖는 행의 DEPARTMENT_NAME을 t_code 변수에 대입
      select DEPARTMENT_NAME into t_code
      from proc_departments
      where DEPARTMENT_ID = p_code;
    end if;
    commit;
  end prc_tree;
/

