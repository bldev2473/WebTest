create trigger EMP_TEST_UPD_LOG
  after update
  on EMP_TRI
  for each row
  begin
    insert into update_log values(:old.EMPLOYEE_ID, :old.LAST_NAME, :new.LAST_NAME);
  end;
/

