create procedure update_sal (v_emp_no in number)
  is
  begin
    update EMPLOYEES
    set SALARY = SALARY + SALARY * 1.1
    where EMPLOYEE_ID = v_emp_no;
    commit;
  end update_sal;
/

