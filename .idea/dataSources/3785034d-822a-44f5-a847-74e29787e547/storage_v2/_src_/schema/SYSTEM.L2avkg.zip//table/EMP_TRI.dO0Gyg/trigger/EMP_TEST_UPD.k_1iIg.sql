create trigger EMP_TEST_UPD
  after update
  on EMP_TRI
  for each row
  begin
    -- emp_tri에서 갱신된 데이터를 emp_trigger에서 갱신
    update emp_empty set LAST_NAME = :new.LAST_NAME where EMPLOYEE_ID = :old.EMPLOYEE_ID;
  end;
/

