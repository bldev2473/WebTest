create trigger EMP_TEST_INS
  after insert
  on EMP_TRI
  for each row
  begin
    insert into emp_empty(EMPLOYEE_ID, LAST_NAME, EMAIL, HIRE_DATE, JOB_ID)
    values(:new.EMPLOYEE_ID, :new.LAST_NAME, :new.EMAIL, :new.HIRE_DATE, :new.JOB_ID); -- emp_tri에 삽입된 데이터를 emp_trigger에 삽입
  end;
/

